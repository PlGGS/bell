//
//  hw3App.swift
//  hw3
//
//  Created by Blake Boris on 5/14/23.
//

import SwiftUI

@main
struct hw3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
