//
//  ErrorTableViewCell.swift
//  hw2
//
//  Created by Blake Boris on 4/28/23.
//

import UIKit

class ErrorTableViewCell: UITableViewCell {
    @IBOutlet weak var lblError: UILabel!
}
