//
//  TerminalTableViewCell.swift
//  hw2
//
//  Created by Blake Boris on 4/28/23.
//

import UIKit

class TerminalTableViewCell: UITableViewCell {
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblLines: UILabel!
    @IBOutlet weak var imgIsADAComplient: UIImageView!
}
